import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-root',
  template: `<mymodule></mymodule>`
})

export class AppComponent {}