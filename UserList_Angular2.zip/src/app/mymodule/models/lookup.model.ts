export class LookupModel{
	public states: any[] = [];
	
	constructor(private data: any = {}){
		this.states = data.states?data.states:this.states;
    }
	
}