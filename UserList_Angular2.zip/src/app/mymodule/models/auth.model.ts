export class AuthModel{
	public userName:string = '';
	public firstName:string = '';
	public lastName:string = '';
	public token:string = '';
	
	constructor(private data: any = {}){
        this.userName = data.userName?data.userName.trim():'';
        this.firstName = data.firstName?data.firstName.trim():'';
		this.lastName = data.lastName?data.lastName.trim():'';
		this.token = data.token?data.token.trim():'';
    }
}