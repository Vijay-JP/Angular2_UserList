export class UserModel{
	public firstName:string = '';
	public lastName:string = '';
	public zip:string = '';
	public address1:string = '';
	public address2:string = '';
	public city:string = '';
	public state:string = '';
	public phone:string = '';
	
	constructor(private data: any = {}){
		this.firstName = data.firstName?data.firstName.trim():'';
		this.lastName = data.lastName?data.lastName.trim():'';
		this.zip = data.zip?data.zip.trim():'';
		this.address1 = data.address1?data.address1.trim():'';
		this.address2 = data.address2?data.address2.trim():'';
		this.city = data.city?data.city.trim():'';
		this.state = data.state?data.state.trim():'';
		this.phone = data.phone?data.phone.trim():'';
    }
	
}