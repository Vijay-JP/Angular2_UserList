import { Component } from '@angular/core';

@Component({
  selector: 'mymodule',
  templateUrl: 'mymodule.component.html'
})

export class MyModuleComponent {
    constructor(){}
}
