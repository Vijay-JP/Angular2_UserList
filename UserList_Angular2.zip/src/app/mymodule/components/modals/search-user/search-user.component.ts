import { Component, Input, OnInit, Inject } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { UserModel } from '../../../models';
import { ModelService } from '../../../service';

@Component({
  moduleId: module.id,
  selector: 'search-user.component',
  templateUrl: 'search-user.component.html'
})

export class SearchUserComponent  implements OnInit{
  
	public users: UserModel[] = [];
	public search: string = "";
	
    constructor(private ms: ModelService, private modalService: NgbActiveModal){
		this.users = ms.userService.userList;
	}
	
	public onClick(id: number): void{
		this.modalService.close();
		window.location.href = "#/edit-user/"+id;
	}
		
	ngOnInit(){}
}
