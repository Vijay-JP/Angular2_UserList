import { Component, Input, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';

import { UserModel, LookupModel } from '../../models';
import { ModelService, UserService, MessageService, ServerService } from '../../service';

@Component({
  moduleId: module.id,
  selector: 'add-user',
  templateUrl: 'add-user.component.html'
})

export class AddUserComponent  implements OnInit{
	
	public userData: UserModel = new UserModel();	
	public lookupData: LookupModel = new LookupModel();	
	public name: string = '';
	public index: number;
	public saveMessages: any;
	public isEdit: boolean = false;
	
    constructor(private mService : ModelService, public uService : UserService, public route: ActivatedRoute, public msgService: MessageService, 
		public serverService : ServerService){this.index = parseInt(route.snapshot.params['id']);
		this.name = mService.authService.auth.userName;
		if(this.index >= 0){
			this.isEdit = true;
			this.userData = this.uService.getUser(this.index);
		}
	}
	
	submitPage = function(){
		this.msgService.clearMessages();
		if(this.uService.validate(this.userData)){
			if(this.index  >= 0){
				this.mService.userService.userList[this.index] = this.userData;		
			}else{
				this.mService.userService.userList.push(this.userData);
			}
			window.location.href = '#/user-list';
		}
		this.saveMessages = this.msgService.getMessages();
	}
	
	loadLookups(){
		this.serverService.getLookupData()
		.subscribe(
			data => {
				this.lookupData = data;
			},
			error => {
				console.log('Error fetching users data', error);
			}
		);
	}
		
	ngOnInit(){
		this.loadLookups();
	}
}
