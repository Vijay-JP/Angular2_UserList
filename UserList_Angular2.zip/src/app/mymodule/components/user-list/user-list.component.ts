import { Component, Input, OnInit, Inject } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { UserModel } from '../../models';
import { ModelService } from '../../service';

import { SearchUserComponent } from '../modals';

@Component({
  moduleId: module.id,
  selector: 'user-list',
  templateUrl: 'user-list.component.html'
})

export class UserListComponent  implements OnInit{
	
	public users: UserModel[] = [];
  
    constructor(private ms: ModelService, private modalService: NgbModal){
		ms.userService.getAllUsers();
    	this.users = ms.userService.userList;
    }
	
	openModal() {
        const modalRef = this.modalService.open(SearchUserComponent, { windowClass: 'search-modal', size: 'lg' });
    }
	
	/*deleteUser(idx:string){
		console.log('here'+idx);
		let index = parseInt(idx);
		this.ms.userService.deleteUser(index);
	}*/
		
	ngOnInit(){}
}
