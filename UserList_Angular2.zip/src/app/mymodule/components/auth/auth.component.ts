import { Component } from '@angular/core';

import { ModelService, ServerService } from '../../service';

@Component({
  moduleId: module.id,
  selector: 'auth',
  templateUrl: 'auth.component.html'
})

export class AuthComponent {
	
	public loginData: any = {"userName": "", "password": ""};
	public isLoggedIn: boolean = false;
	public loggedInMessage: string = "";
	
    constructor(private mService : ModelService, private sService: ServerService){}
	
	public login(): void{
		this.sService.checkAuth(this.loginData)
        .subscribe(
            auth => {
				this.mService.authService.setAuth(auth);
				this.isLoggedIn = this.mService.authService.isLoggedIn();
				if(this.isLoggedIn){
					window.location.href = '#/user-list';
				} else {
					this.loggedInMessage = "* Wrong Username or Password !";
				}
            },
            error => {
                console.log('Error fetching users data', error);
				return false;
            }
        );
	}
}
