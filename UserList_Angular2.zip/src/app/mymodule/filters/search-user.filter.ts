import {Injectable, Pipe, PipeTransform} from '@angular/core';

import { UserModel } from '../models';

@Pipe({
  name: 'searchUserFilter',
  pure: false
})
@Injectable()
export class SearchUserFilter implements PipeTransform {
	transform(users: UserModel[], args: any[]): any {
		if (!users || !args) {
			return [];
		}
		return users.filter((user:  UserModel) => this.applyFilter(user, args));
	}
	
	private applyFilter(user: UserModel, args: any[]): boolean {
		return (user.firstName.toLowerCase().indexOf(args[0].toLowerCase()) !== -1);
	}
}