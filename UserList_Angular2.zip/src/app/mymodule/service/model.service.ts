import { Injectable } from '@angular/core';

import { UserService } from './user.service';
import { AuthService } from './auth.service';
//import { LookupService } from './lookup.service';

@Injectable()
export class ModelService {

	constructor(
		public userService : UserService,
		public authService : AuthService
		//public lookupService : ServerService
	){}
}
