import { Injectable } from '@angular/core';

@Injectable()
export class MessageService {
	
	public messages: string[] = [];
	public status: string = '';
	
	constructor(){}
	
	public getMessages(): any{
		return {messages: this.messages, status: this.status};
	}
	
	public setMessage(msg: string): void{
		this.messages.push(msg);
	}
	
	public setStatus(status: string): void{
		this.status = status;
	}
	
	public clearMessages(): void{
		this.messages = [];
		this.status = '';
	}
	
	public hasMessage(): boolean{
		return (this.messages.length > 0?true:false);
	}
	
}
