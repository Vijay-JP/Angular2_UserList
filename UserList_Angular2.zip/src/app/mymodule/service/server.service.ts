import { Injectable } from '@angular/core';
import { Headers, Http, Response } from '@angular/http';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class ServerService {

    private headers: Headers = new Headers({ 'Content-Type': 'application/json' });

	private WSURL_AUTH: string = 'http://localhost:4200/assets/demo_json/auth.json';
    private WSURL_USERS: string = 'http://localhost:4200/assets/demo_json/users.json';
    private WSURL_LOOKUP: string = 'http://localhost:4200/assets/demo_json/lookup.json';
	private WSURL_RESTCALL: string = 'http://localhost:8075/Restservice/rest/ConversionService/FeetToInch/2';

    constructor (private http: Http) {}

	 public checkAuth(data: any): Observable<any>  {
        console.log('Checking Auth login.');
        return this.http.get(this.WSURL_AUTH)
            .map((response: Response) => {
                try {
                    return response.json();
                } catch (e) {
                    console.log(e);
                }
            })
            .catch((serverError: Response) => {
                return Observable.throw(`${serverError}`)
            })
    }
	
    public getAllUsers(): Observable<any>  {
        console.log('get user data from server.')
        return this.http.get(this.WSURL_USERS)
            .map((response: Response) => {
                try {
                    return response.json();
                } catch (e) {
                    console.log(e);
                }
            })
            .catch((serverError: Response) => {
                return Observable.throw(`${serverError}`)
            })
    }
	
	public getLookupData(): Observable<any>  {
        console.log('get lookup data from server.')
        return this.http.get(this.WSURL_LOOKUP)
            .map((response: Response) => {
                try {
                    return response.json();
                } catch (e) {
                    console.log(e);
                }
            })
            .catch((serverError: Response) => {
                return Observable.throw(`${serverError}`)
            })
    }

	/*public restCall(): Observable<any>  {
        console.log('rest call from eclipse.');
        return this.http.get(this.WSURL_RESTCALL)
            .map((response: Response) => {
                try {
                    return response.json();
                } catch (e) {
                    console.log(e);
                }
            })
            .catch((serverError: Response) => {
                return Observable.throw(`${serverError}`)
            })
    }*/
}
