import { Injectable } from '@angular/core';

import { UserModel } from '../models';
import { ServerService } from './server.service';
import { MessageService } from './message.service';

@Injectable()
export class UserService {
	
	public userList: UserModel[] = [];
	
	constructor(public serverService: ServerService, public messageService: MessageService){}
	
	public getAllUsers(): void{
		if(this.userList.length === 0){
			this.serverService.getAllUsers()
			.subscribe(
				userList => {
					for(let idx in userList){
						this.userList.push(new UserModel(userList[idx]));
					}
				},
				error => {
					console.log('Error fetching users data', error);
				}
			);
		}
	}
	
	public getUser(id: number): UserModel{
		return this.userList[id];
	}
	
	/*public deleteUser(index: number): void{
		this.serverService.restCall()
		.subscribe(
			data => {
				console.log("rest DAta"+data);
			},
			error => {
				console.log('Error fetching users data', error);
			}
		);
	}*/
	
    public validate(data: UserModel): any {
		let isValid: boolean = true;
		if(data.firstName.length < 3){
			isValid = false;
			this.messageService.setMessage("* Firstname can not blank");
			this.messageService.setStatus("error");
		}
		if(data.lastName.length < 3){
			isValid = false;
			this.messageService.setMessage("* Lastname can not blank");
			this.messageService.setStatus("error");
		}
		if(data.address1.length <= 0){
			isValid = false;
			this.messageService.setMessage("* Address 1 can not blank");
			this.messageService.setStatus("error");
		}
		if(data.zip.length != 6){
			isValid = false;
			this.messageService.setMessage("* Zip should be 6 digit");
			this.messageService.setStatus("error");
		}
		if(data.phone.length != 10){
			isValid = false;
			this.messageService.setMessage("* Phone number should be 10 digit");
			this.messageService.setStatus("error");
		}
		return isValid;
	}
}
