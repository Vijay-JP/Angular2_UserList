import { Injectable } from '@angular/core';

import { AuthModel } from '../models';
import { ServerService } from './server.service';

@Injectable()
export class AuthService {
	
	public auth: AuthModel = new AuthModel();
	
	constructor(public serverService: ServerService){}
	
	public isLoggedIn(): boolean{
		return (this.auth.token && this.auth.token != '');
	}
	
	public setAuth(data: any): void{
		this.auth = new AuthModel(data);
	}
	
	public getAuth(): any{
		return this.auth;
	}
}
