import { Injectable } from '@angular/core';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';

import { ServerService } from './server.service';
//import { LookupModel } from '../models';

@Injectable()
export class LookupService {
	
	//public lookupData: LookupModel[];
	
	constructor(public serverService: ServerService){}
	
	public getLookupData(): any{
		this.serverService.getLookupData()
		.subscribe(
			data => {
				console.log(data);
				return data;
			},
			error => {
				console.log('Error fetching users data', error);
			}
		);
	}
}
