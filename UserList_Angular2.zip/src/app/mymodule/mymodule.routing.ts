import { Routes, RouterModule } from '@angular/router';

import { HomeComponent, AuthComponent, AddUserComponent, UserListComponent } from './components';

const appRoutes: Routes = [
    { path: '', component: HomeComponent },
	{ path: 'login', component: AuthComponent },
	{ path: 'add-user', component: AddUserComponent },
	{ path: 'user-list', component: UserListComponent },
	{ path: 'edit-user/:id', component: AddUserComponent }
];

export const routing = RouterModule.forRoot(appRoutes, { useHash: true });
