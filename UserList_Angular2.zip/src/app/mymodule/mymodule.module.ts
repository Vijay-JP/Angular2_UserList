import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {NgbModule, NgbModal} from '@ng-bootstrap/ng-bootstrap';
 
import { routing } from './mymodule.routing';
import { MyModuleComponent } from './mymodule.component';

import { HomeComponent, AuthComponent, AddUserComponent, UserListComponent } from './components';
import { SearchUserComponent } from  './components/modals';
import { ModelService, UserService, ServerService, AuthService, MessageService, LookupService } from './service';
import { SearchUserFilter } from './filters';

import {AutoCompleteModule} from 'primeng/primeng';

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        HttpModule,
		routing,
		AutoCompleteModule,
		NgbModule.forRoot()
    ],
    declarations: [
        MyModuleComponent,
		HomeComponent,
		AuthComponent,
		AddUserComponent,
		UserListComponent,
		SearchUserComponent,
		SearchUserFilter
    ],
    providers: [
        ModelService,
		UserService,
		ServerService,
		AuthService,
		MessageService,
		LookupService
	],
	entryComponents: [
		SearchUserComponent
	],
    exports: [MyModuleComponent]
})
export class MyModule {
    constructor() {}
}
