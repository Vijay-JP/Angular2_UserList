import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { MyModule } from './mymodule/mymodule.module';

@NgModule({
	imports: [MyModule],
	declarations: [AppComponent],
	bootstrap: [AppComponent]
})
export class AppModule { }
